const mailgun_auth = {
  user: 'postmaster@uwclasswatch.com',
  pass: 'UWClassWatch!!'
};

exports.mailgun_auth = mailgun_auth;