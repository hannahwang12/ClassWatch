const api_key = "key-48cba8ba4b9af223a3ee2797cb413ade";

exports.api_key = api_key;